# HTML-Scripts

Miscellaneous useful HTML scripts.

 - **Unicode Text Transformer**
   - It uses Unicode characters in different font styles to transform plain text into rich text that you can copy & paste.
